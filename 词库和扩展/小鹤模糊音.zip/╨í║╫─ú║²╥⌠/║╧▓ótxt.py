import os

# 获取当前文件夹路径
current_folder = os.getcwd()

# 遍历当前文件夹中的所有文件
file_list = [file for file in os.listdir(current_folder) if file.endswith(".txt")]

# 合并txt文件
with open("merged.txt", "w", encoding="utf-8") as output_file:
    for file_name in file_list:
        with open(file_name, "r", encoding="utf-8") as input_file:
            output_file.write(input_file.read() + "\n")