from openpyxl import load_workbook
from collections import OrderedDict
import os


# 打开 Excel 文件  填写当前文件
workbook = load_workbook('../模糊音.xlsx')
# workbook = load_workbook('D:\整理\目录类\打字码\汉心快打\全拼汉心15.xlsx')

# 选择要操作的表格
sheet = workbook['模糊音']

# 定义要获取数据的列
columns = ['M','N','P','Q', 'S',  'T', 'V',  'W', 'Y',  'Z', 'AB', 'AC', ]

# 定义临时列表字典
temp_column_data = {column: [] for column in columns}

# 获取指定列的数据到临时列表字典
for column in columns:
    for cell in sheet[column]:
        if cell.value is not None:
            value = str(cell.value) if not isinstance(cell.value, str) else cell.value
            temp_column_data[column].append(value)

# 去除临时列表中的空行
for column in columns:
    temp_column_data[column] = [data for data in temp_column_data[column] if data.strip() != '']

# 保存数据到文本文件--------列名是文件名
#for column in columns:
#    column_name = sheet[column + '1'].value  # 获取列名称
#    with open(column_name + '.txt', 'w', encoding='utf-8') as file:
#        for data in temp_column_data[column]:
#            try:
#                file.write(str(data) + '\n')
#            except UnicodeEncodeError:
#                pass

# 保存数据到文本文件--------列名是文件名----按空格区分左右对调位置

for column in columns:
    column_name = sheet[column + '1'].value  # 获取列名称
    with open(column_name + '.txt', 'w', encoding='utf-8') as file:
        for data in temp_column_data[column]:
            try:
                reversed_data = '	'.join(str(data).split()[::-1])  # 将左右字符对调位置
                file.write(reversed_data + '\n')
            except UnicodeEncodeError:
                pass


# # 保存工作簿名加列名

# for column in columns:
#     column_name = sheet[column + '1'].value  # 获取列名称
#     workbook_name = workbook.active.title  # 获取工作簿名
#     file_name = f"{workbook_name}_{column_name}.txt"  # 设置文件名
#     with open(file_name, 'w', encoding='utf-8') as file:
#         for data in temp_column_data[column]:
#             try:
#                 file.write(str(data) + '\n')
#             except UnicodeEncodeError:
#                 pass




# # 指定名加列名

# for column in columns:
#     column_name = sheet[column + '1'].value  # 获取列名称
#     file_name = f"模糊音{column_name}.txt"  # 设置文件名
#     with open(file_name, 'w', encoding='utf-8') as file:
#         for data in temp_column_data[column]:
#             try:
#                 file.write(str(data) + '\n')
#             except UnicodeEncodeError:
#                 pass











# # 选择要操作的表格  操作第二个表格
# sheet = workbook['Sheet2']


# # 定义要获取数据的列
# columns = ['A']  # 指定要获取的列，可以根据需要进行修改

# # 定义临时列表字典
# temp_column_data = {column: [] for column in columns}

# # 获取指定列的数据到临时列表字典
# for column in columns:
#     for cell in sheet[column]:
#         if cell.value is not None:
#             value = str(cell.value) if not isinstance(cell.value, str) else cell.value
#             temp_column_data[column].append(value)

# # 去除临时列表中的空行
# for column in columns:
#     temp_column_data[column] = [data for data in temp_column_data[column] if data.strip() != '']

# # 保存数据到文本文件
# for column in columns:
#     column_name = sheet[column + '1'].value  # 获取列名称
#     with open(column_name + '.txt', 'w', encoding='utf-8') as file:
#         for data in temp_column_data[column]:
#             try:
#                 file.write(str(data) + '\n')
#             except UnicodeEncodeError:
#                 pass












# 关闭 Excel 文件
workbook.close()
