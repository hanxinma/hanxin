def dedup(l):
    vis = set()
    ret = []
    for e in l:
        if e not in vis and e + chr(0xfe0f) not in vis:
            vis.add(e)
            ret.append(e)
    return ret

def read_txt(p):
    res = dict()
    with open(p, 'r') as f:
        for l in f:
            l = l.strip()
            [k, vs] = l.split('\t')
            vs = vs.split(' ')
            res[k] = dedup(vs)
    return res


def write(a, p):
    with open(p, 'w') as f:
        for k, vs in a.items():
            f.write(f'{k}\t{" ".join(vs)}\n')


a = read_txt('moran_emoji.txt')
write(a, "merged.txt")
